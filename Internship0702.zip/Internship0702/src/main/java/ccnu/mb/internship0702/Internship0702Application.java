package ccnu.mb.internship0702;

import ccnu.mb.internship0702.controllers.UserController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Internship0702Application {

    public static void main(String[] args) {
        SpringApplication.run(Internship0702Application.class, args);

    }

}
