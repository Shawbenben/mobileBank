package ccnu.mb.internship0702;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Internship0702ApplicationTests {

    @Test
    void contextLoads() {
    }

}
